package com.centennial.donateblood

import android.os.Bundle

class RegistrationActivity: BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registration)
    }

    fun validateForm(){

    }
}